document.addEventListener("DOMContentLoaded", function() {
    var header = document.querySelector(".header");
    var backToTopButton = document.querySelector(".back-to-top");

    window.addEventListener("scroll", function() {
        var scrollTop = window.pageYOffset || document.documentElement.scrollTop;

        if (scrollTop >= 20) {
            header.classList.add("with-effect");
        } else {
            header.classList.remove("with-effect");
        }

        var content = document.querySelector(".content");
        if (scrollTop >= 20) {
            content.classList.add("up");
        } else {
            content.classList.remove("up");
        }

        if (scrollTop > 100) {
            backToTopButton.style.display = "block";
        } else {
            backToTopButton.style.display = "none";
        }

        document.querySelectorAll('.section-content .image-container').forEach(function(container) {
            var rect = container.getBoundingClientRect();
            if (rect.top >= 0 && rect.bottom <= window.innerHeight) {
                container.classList.add('visible');
            } else {
                container.classList.remove('visible');
            }
        });

        document.querySelectorAll('.section-content.reversed .image-container').forEach(function(container) {
            var rect = container.getBoundingClientRect();
            if (rect.top >= 0 && rect.bottom <= window.innerHeight) {
                container.classList.add('visible');
            } else {
                container.classList.remove('visible');
            }
        });
    });

    backToTopButton.addEventListener("click", function() {
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    });
});